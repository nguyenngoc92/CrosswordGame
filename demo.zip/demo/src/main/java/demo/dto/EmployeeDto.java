package demo.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class EmployeeDto implements Serializable {
	
	@JacksonXmlElementWrapper(localName = "employees")
	@JsonProperty("employees")
	private List<Employee> employees = new ArrayList<>();

	public List<Employee> getEmployees() {
		return employees;
	}
	
	@JsonSetter
    public void setEmployee(Employee employee) {
        this.employees.add(employee);
    }

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
}
