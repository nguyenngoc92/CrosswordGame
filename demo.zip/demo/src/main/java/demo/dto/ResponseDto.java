package demo.dto;

import java.util.Map;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonGetter;

/**
 * The ResponseDto class
 */
public class ResponseDto {
	private Object body;
	private Map<String, String> headers;
	private HttpStatus statusCode;
	private String message;
	private Object parameter;

	public ResponseDto() {
		super();
	}

	public ResponseDto(Object body, Map<String, String> headers, HttpStatus status, String message, Object parameter) {
		this.body = body;
		this.headers = headers;
		this.statusCode = status;
		this.message = message;
		this.parameter = parameter;
	}

	public ResponseDto(Object body, Map<String, String> headers, HttpStatus status, String message) {
		this.body = body;
		this.headers = headers;
		this.statusCode = status;
		this.message = message;
	}

	public ResponseDto(Object body, Map<String, String> headers, HttpStatus statusCode) {
		super();
		this.body = body;
		this.headers = headers;
		this.statusCode = statusCode;
	}

	public ResponseDto(Object body, HttpStatus statusCode, String message) {
		super();
		this.body = body;
		this.statusCode = statusCode;
		this.message = message;
	}

	public ResponseDto(Object body, HttpStatus statusCode, String message, Object parameter) {
		super();
		this.body = body;
		this.statusCode = statusCode;
		this.message = message;
		this.parameter = parameter;
	}

	public ResponseDto(HttpStatus statusCode, String message, Object parameter) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.parameter = parameter;
	}

	public ResponseDto(Object body, HttpStatus statusCode) {
		this.body = body;
		this.statusCode = statusCode;
	}

	public ResponseDto(HttpStatus statusCode, String message) {
		this.statusCode = statusCode;
		this.message = message;
	}

	public ResponseDto(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}

	@JsonGetter("statusCode")
	public int getStatusValue() {
		return statusCode.value();
	}

	public Object getBody() {
		return body;
	}

	public void setBody(Object body) {
		this.body = body;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getParameter() {
		return parameter;
	}

	public void setParameter(Object parameter) {
		this.parameter = parameter;
	}

}
