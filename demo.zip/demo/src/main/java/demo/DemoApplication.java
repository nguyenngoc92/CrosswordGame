package demo;

import java.io.File;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

	@Value("${image.folder}")
	private String imageForder;

	@Value("${archive.folder}")
	private String archiveFolder;

	@Value("${output.file}")
	private String outputFolder;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		File imagePath = new File(imageForder);
		if (!imagePath.exists() || !imagePath.isDirectory()) {
			imagePath.mkdirs();
		}

		File archivePath = new File(archiveFolder);
		if (!archivePath.exists() || !archivePath.isDirectory()) {
			archivePath.mkdirs();
		}

		File outputPath = new File(outputFolder);
		if (!outputPath.exists() || !outputPath.isDirectory()) {
			outputPath.mkdirs();
		}
	}

}
