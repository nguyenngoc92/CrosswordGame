package demo.api;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import demo.dto.Employee;
import demo.dto.EmployeeDto;
import demo.dto.ResponseDto;
import demo.excel.ExcelGenerator;

@RestController
public class Api {

	@Value("${image.folder}")
	private String imageForder;

	@Value("${archive.folder}")
	private String archiveFolder;
	
	@Value("${output.file}")
	private String outputFolder;
	
	@Value("${xls.name}")
	private String sheetName;
	
	@Autowired
	private ExcelGenerator excelGenerator;

	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");

	@RequestMapping(value = "/api/user", method = RequestMethod.POST, consumes = { "multipart/form-data" })
	public ResponseDto user(@RequestParam("file") MultipartFile file, @RequestParam("users") String users) {

		if (file == null) {
			return new ResponseDto(HttpStatus.BAD_REQUEST, "Invalid image file upload");
		}

		String fileContentType = file.getContentType();
		if (!fileContentType.startsWith("image/")) {
			return new ResponseDto(HttpStatus.BAD_REQUEST, "Invalid image file upload");
		}

		String originalFilename = file.getOriginalFilename();
		System.out.println(originalFilename);
		int index = Math.max(originalFilename.lastIndexOf('/'), originalFilename.lastIndexOf('\\'));
		String fileName = originalFilename;
		if (index > -1) {
			fileName = originalFilename.substring(index, originalFilename.length());
		}

		try {
			saveFile(file, fileName);

			System.out.println(users);

			XmlMapper xmlMapper = new XmlMapper();
			EmployeeDto dto = xmlMapper.readValue(users, EmployeeDto.class);

			if (dto != null) {
				List<Employee> employees = dto.getEmployees();
				if (employees != null) {
					for (Employee e : employees) {
						String firstName = e.getFirstname();
						if(firstName == null || firstName.trim().isEmpty()) {
							return new ResponseDto(HttpStatus.BAD_REQUEST, "First name cannot be null or empty");
						}else if(!isStringOnlyAlphabet(firstName.trim())) {
							return new ResponseDto(HttpStatus.BAD_REQUEST, "First name only accept alphabet character");
						}
						String lastName = e.getLastname();
						if(lastName == null || lastName.trim().isEmpty()) {
							return new ResponseDto(HttpStatus.BAD_REQUEST, "Last name cannot be null or empty");
						}else if(!isStringOnlyAlphabet(lastName.trim())) {
							return new ResponseDto(HttpStatus.BAD_REQUEST, "Last name only accept alphabet character");
						}
						
						String dob = e.getDob();
						if(dob == null || dob.trim().isEmpty()) {
							return new ResponseDto(HttpStatus.BAD_REQUEST, "Dob cannot be null or empty");
						}else {
							try {
								dateFormat.parse(dob);
							}catch (Exception ex) {
								return new ResponseDto(HttpStatus.BAD_REQUEST, "Dob invalid format: yyyy/mm/dd");
							}
							
						}

					}
					
					excelGenerator.employeesToExcel(employees);
					
				}
			}
			return new ResponseDto(dto, HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseDto(HttpStatus.BAD_REQUEST, e.getMessage());
		}

//		return new ResponseDto(HttpStatus.OK);
	}

	private void saveFile(MultipartFile file, String fileName) throws Exception {
		try {

			byte[] bytes = file.getBytes();
			Path path = Paths.get(imageForder + "/" + fileName);
			if (Files.exists(path)) {
				Path archiveFilePath = Paths.get(archiveFolder + "/" + fileName);
				Files.move(path, archiveFilePath, StandardCopyOption.REPLACE_EXISTING);
			}
			Files.write(path, bytes);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to upload file.");
		}
	}

	// Function to check String for only Alphabets
	public static boolean isStringOnlyAlphabet(String str) {
		return ((str != null) && (!str.equals("")) && (str.matches("^[a-zA-Z]*$")));
	}
}
